


int foo1() { return 1; }

int foo2() { return 2; }

#ifndef NO_FOO34
  int foo3() { return 3; }
  int foo4() { return 4; }
#endif

