int sub2()
{
	return 2;
}

