
int foo = 42;

