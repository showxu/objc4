
void foo() { }
