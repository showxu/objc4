
void foo() {
}

