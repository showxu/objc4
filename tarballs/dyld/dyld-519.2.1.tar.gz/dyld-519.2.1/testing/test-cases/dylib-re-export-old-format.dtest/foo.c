
int foo = 1;

