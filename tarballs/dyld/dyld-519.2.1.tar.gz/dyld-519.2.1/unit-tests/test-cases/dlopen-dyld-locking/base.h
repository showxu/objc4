
extern void waitForState(int);
extern void setState(int);
