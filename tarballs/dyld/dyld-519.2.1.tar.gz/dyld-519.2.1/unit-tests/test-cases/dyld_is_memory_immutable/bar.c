


const char* bar()
{
    return "bar";
}
