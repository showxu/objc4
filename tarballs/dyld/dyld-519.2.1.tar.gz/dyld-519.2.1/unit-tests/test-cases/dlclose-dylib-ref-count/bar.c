

int bar()
{
	return 10;
}
