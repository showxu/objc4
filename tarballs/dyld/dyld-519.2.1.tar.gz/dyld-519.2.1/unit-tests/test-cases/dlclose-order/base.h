#include <stdbool.h>

extern bool barInitied;
extern bool barTeminated;

extern bool bazInitied;
extern bool bazTeminated;


